import pygame
from math import sqrt
from random import randint

def normalize(vec):
    try:
        length = sqrt(vec[0]**2 + vec[1]**2)
        vec = (vec[0]/length, vec[1]/length)
        return vec
    except: return (0,0)
def s(time):
    return time*60

def dist(p1,p2):
    return sqrt((p2[0]-p1[0])**2+(p2[1]-p1[1])**2)

# --- GAME --- #
class Vec2:
    def __init__(self, x=None, y=None, tuple=None):
        if tuple == None:
            self.x = x
            self.y = y
        else:
            self.x = tuple[0]
            self.y = tuple[1]

class Cursor:
    def __init__(self):
        # specifics
        self.pos = [-100,-100]

        # shooting
        self.click = False
        self.clickDelay = 10
        self.shown = False
        self.data = None

        # sprite
        self.width = 6
        self.color = (100,100,100)

class Player:
    def __init__(self,
                 position=(0,0),
                 velocity={'right':0, 'up':0, 'left':0, 'down':0},
                 speed=2
                ):
        # position
        self.pos = position
        self.vel = velocity
        self.speed = speed
        self.baseSpeed = speed

        # states
        self.isDashing = False
        self.dashTime = 10
        self.dashBaseTime = 10

        # sprite
        self.width = 20
        self.color = (255,255,255)

class Projectile:
    def __init__(self, pos, vel, speed):
        # position
        self.pos = pos
        self.vel = vel
        self.speed = speed
        self.lifeTime = 120

        # sprite
        self.width = 3
        self.color = (255,255,255)

class Enemy:
    def __init__(self,
                 target,
                 aistyle='basic',
                 pos=(1000,250),
                 velocity=(0,0),
                 speed=2
                ):
            # position
            self.pos = pos
            self.vel = velocity
            self.speed = speed
            self.baseSpeed = speed
            self.target = target

            # AI
            self.aistyle = aistyle
            self.ai = {}
            if self.aistyle == 'basic':
                self.ai = {'shoot_speed':15,
                           'shoot_delayMax':25,
                           'shoot_delay':25,
                           'mov_style':'chase-retreat',
                          }

            # sprite
            self.width = 20
            self.color = (255,0,0)

    def update(self):
        self.ai['shoot_delay'] -= 1
        if self.ai['mov_style'] == 'chase-retreat':
            if dist(self.pos, self.target.pos)>150:
                vel_ = normalize((self.target.pos[0]-self.pos[0], self.target.pos[1]-self.pos[1]))
                self.pos = ( self.pos[0]+vel_[0]*self.speed , self.pos[1]+vel_[1]*self.speed )
            elif dist(self.pos, self.target.pos)<145:
                vel_ = normalize((self.target.pos[0]-self.pos[0], self.target.pos[1]-self.pos[1]))
                self.pos = ( self.pos[0]+vel_[0]*-self.speed , self.pos[1]+vel_[1]*-self.speed )

# --- UI --- #
class Label:
    def __init__(self, position, size=15, color=(255,255,255), text='', centered=True):
        self.position = position
        self.size = size
        self.color = color
        self.text = text
        self.centered = centered

    def draw(self, surface, text=''):
        if text != '':
            font = pygame.font.Font('OpenSans-Regular.ttf', self.size)
            text = font.render(text, 1, self.color)
            if self.centered:
                surface.blit(text, (self.position.x-text.get_width()/2, self.position.y-text.get_height()/2))
            else:
                surface.blit(text, (self.position.x, self.position.y))