# MODULES
import pygame
# .PY
from funcs import *
from classes.projectile import *

class Cursor:
    def __init__(self):
        # specifics
        self.pos = [-100,-100]

        # shooting
        self.click = False
        self.clickDelay = 25
        self.clickDelayMax = 25
        self.shown = False
        self.data = None

        # sprite
        self.sprite = pygame.image.load('sprites/cursor.png')
    
    def update(self, player, projectiles, enemies, particles):
        if self.click and self.clickDelay <= 0:
            self.clickDelay = self.clickDelayMax
            vel = normalize((self.pos[0]-player.pos[0], self.pos[1]-player.pos[1]))
            projectiles.append(Projectile((player.pos[0]+int(player.width/2), player.pos[1]+int(player.width/2)), vel, 25, team='player'))
            for i in range(5):
                c = randint(0,255)
                particles.append([(player.pos[0]+player.width/2+randint(-3,3), player.pos[1]+player.width/2+randint(-3,3)), ((vel[0]+uniform(-0.5,0.5))*6,(vel[1]+uniform(-0.5,0.5))*6), (c,c,c), 4])
        self.clickDelay -= 1