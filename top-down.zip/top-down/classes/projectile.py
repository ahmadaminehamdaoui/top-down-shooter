# MODULES
from random import randint, uniform
# .PY
from funcs import *

class Projectile:
    def __init__(self, pos, vel, speed, team='enemy'):
        # position
        self.pos = pos
        self.vel = vel
        self.speed = speed
        self.lifeTime = 120

        # sprite
        self.width = 4
        self.color = (255,255,255)

        # others
        self.team = team

    def update(self, player, projectiles, enemies, particles, scr):
        for i in range(self.speed):
            if self.team == 'player':
                for e in enemies:
                    if e.spawntime <= 0 and isColliding(self.pos, e.pos, self.width, e.width):
                        if self in projectiles:
                            e.hit()
                            for j in range(5):
                                coef = randint(50,100)
                                r = e.color[0]*(coef/100)
                                g = e.color[1]*(coef/100)
                                b = e.color[2]*(coef/100)
                                particles.append([(e.pos[0]+e.width/2+randint(-3,3), e.pos[1]+e.width/2+randint(-3,3)), ((self.vel[0]+uniform(-0.5,0.5))*8,(self.vel[1]+uniform(-0.5,0.5))*8), (r,g,b), 8])
                            projectiles.remove(self)
                            break
                self.pos = ( self.pos[0]+self.vel[0] , self.pos[1]+self.vel[1] )
            else:
                if isColliding(self.pos, player.pos, self.width, player.width):
                    projectiles.remove(self)
                    break
                else:
                    self.pos = ( self.pos[0]+self.vel[0] , self.pos[1]+self.vel[1] )
        
        if (self.pos[0]<0 or self.pos[0]>scr.w or self.pos[1]<0 or self.pos[1]>scr.h or self.lifeTime <= 0):
            if self in projectiles:
                projectiles.remove(self)