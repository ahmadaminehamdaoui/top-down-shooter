import pygame
from math import sqrt
from random import randint

class Label:
    def __init__(self, position, size=15, color=(255,255,255), text='', centered=True):
        self.position = position
        self.size = size
        self.color = color
        self.text = text
        self.centered = centered

    def draw(self, surface, text=''):
        if text != '':
            font = pygame.font.Font('fonts/OpenSans-Regular.ttf', self.size)
            text = font.render(text, 1, self.color)
            if self.centered:
                surface.blit(text, (self.position[0]-text.get_width()/2, self.position[1]-text.get_height()/2))
            else:
                surface.blit(text, (self.position[0], self.position[1]))