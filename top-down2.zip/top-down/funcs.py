# MODULES
import pygame, sys
from math import sqrt, radians, cos, sin

def shutdown():
    pygame.quit()
    sys.exit()

def normalize(vec):
    try:
        length = sqrt(vec[0]**2 + vec[1]**2)
        vec = (vec[0]/length, vec[1]/length)
        return vec
    except: return (0,0)

def dist(p1,p2):
    return sqrt((p2[0]-p1[0])**2+(p2[1]-p1[1])**2)

def rotateVector(vec, degrees):
    angle = radians(degrees)
    return (vec[0] * cos(angle) - vec[1] * sin(angle), vec[0] * sin(angle) + vec[1] * cos(angle))

# GAME FUNCTIONS
def isColliding(rect1, rect2, width1, width2):
    width1 -= 1
    width2 -= 1
    if rect1[0] < rect2[0]+width2 and rect1[0]+width1 > rect2[0] and rect1[1] < rect2[1] + width2 and width1 + rect1[1] > rect2[1]:
        return True
    return False

def isPointColliding(point, rect, width):
    width -= 1
    # 3EME ET + A FINIR
    if point[0]<rect[0]+width and point[0]>rect[0] and point[1]<rect[1]+width and point[1]>rect[1]:
        return True
    return False

def s(time):
    return time*60