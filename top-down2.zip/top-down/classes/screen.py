# MODULES
import ctypes

user32 = ctypes.windll.user32
class Screen:
    def __init__(self):
        self.w, self.h = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
        self.w_2 = int(self.w/2)
        self.h_2 = int(self.h/2)
        self.cen = (self.w_2, self.h_2)