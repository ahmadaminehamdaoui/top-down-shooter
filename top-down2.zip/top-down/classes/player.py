# MODULES
import pygame

class Player:
    def __init__(self,
                 position=(0,0),
                 velocity={'right':0, 'up':0, 'left':0, 'down':0},
                 speed=2
                ):
        # position
        self.pos = position
        self.vel = velocity
        self.speed = speed
        self.baseSpeed = speed
        self.life = 10

        # states
        self.isDashing = False
        self.dashTime = 10
        self.dashBaseTime = 10

        # sprite
        self.width = 20
        self.color = (255,255,255)

    def update(self, scr):
        if self.life <= 0:
            self.pos = (-10000, -10000)
        for i in range(self.speed):
            save = self.pos
            self.pos = ( self.pos[0]+(self.vel['right']-self.vel['left']) , self.pos[1]+(self.vel['down']-self.vel['up']) )
            if self.pos[0]<0 or self.pos[0]+self.width>scr.w or self.pos[1]<0 or self.pos[1]+self.width>scr.h:
                self.pos = save
        if self.isDashing:
            self.color = (0,255,255)
            self.speed = self.baseSpeed*4
            self.dashTime -= 1
            if self.dashTime <= 0:
                self.dashTime = self.dashBaseTime
                self.isDashing = False
        else:
            self.color = (255,255,255)
            self.speed = self.baseSpeed

    def draw(self, screen):
        pygame.draw.rect(screen, (200,200,200), pygame.Rect(self.pos[0], self.pos[1], self.width, self.width))
        pygame.draw.rect(screen, self.color, pygame.Rect(self.pos[0], self.pos[1]+self.width, self.width, -self.life*2))

    def hit(self):
        self.life -= 1