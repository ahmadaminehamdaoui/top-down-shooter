# MODULES
import pygame
from math import radians, cos, sin
from random import randint
# .PY
from funcs import *
from classes.projectile import Projectile

class Enemy:
    def __init__(self,
                 target,
                 aistyle='basic',
                 pos=(1000,250),
                ):
        # position
        self.pos = pos
        self.vel = (0,0)
        self.target = target

        self.spawntime = 100
        self.hitFrame = 5

        self.aistyle = aistyle
        self.ai = {}
        if self.aistyle == 'basic':
            self.ai = {'shoot_speed':8,
                        'shoot_delayMax':45,
                        'shoot_delay':randint(0,45),
                        'reload_delayMax':0,
                        'reload_delay':0,
                        'charger':1000,
                        'chargerMax':1000,

                        'retreat_distance':randint(125,165),
                        'idle_distance':randint(205, 245)
                        }
            self.color = (255,0,0)
            self.speed = 2
            self.life = 4

        elif self.aistyle == 'rifle':
            self.ai = {'shoot_speed':8,
                        'shoot_delayMax':4,
                        'shoot_delay':4,
                        'reload_delayMax':80,
                        'reload_delay':randint(0,80),
                        'charger':0,
                        'chargerMax':4,

                        'retreat_distance':145,
                        'idle_distance':225
                        }
            self.color = (255,196,0)
            self.speed = 2.5
            self.life = 3

        elif self.aistyle == 'shotgun':
            self.ai = {'shoot_speed':10,
                        'shoot_delayMax':100,
                        'shoot_delay':randint(0,100),
                        'reload_delayMax':0,
                        'reload_delay':0,
                        'charger':1000,
                        'chargerMax':1000,

                        'bullets':3,
                        'spread_angle':10,

                        'circle_angle': randint(0,360),
                        'circle_radius': randint(100,350,),
                        'circle_vel':(0,0),
                        }
            self.color = (0,255,0)
            self.speed = 1.75
            self.life = 6

        elif self.aistyle == 'bouncer':
            self.ai = {'shoot_speed':25,
                        'shoot_delayMax':100,
                        'shoot_delay':randint(25,100),
                        'reload_delayMax':0,
                        'reload_delay':0,
                        'charger':1000,
                        'chargerMax':1000,

                        'bounces':3,
                        'retreat_distance':425,
                        'idle_distance':455
                        }
            self.color = (52, 168, 235)
            self.speed = 3
            self.life = 6

        # sprite
        self.width = 23
        self.color_ = self.color

    def update(self, player, projectiles, enemies, particles, current_fps):
        if self.spawntime <= 0:
            # ----- AI ----- #
            # -- shooting -- #
            self.ai['shoot_delay'] -= 1

            # charger
            if self.ai['charger']<=0:
                self.ai['reload_delay'] -= 1
                if self.ai['reload_delay']<=0:
                    self.ai['reload_delay'] = randint(self.ai['reload_delayMax']-2, self.ai['reload_delayMax']+2)
                    self.ai['charger'] = self.ai['chargerMax']

            # shooting
            elif self.ai['shoot_delay']<=0:
                self.ai['charger'] -= 1
                self.ai['shoot_delay'] = randint(self.ai['shoot_delayMax']-2,self.ai['shoot_delayMax']+2)
                vel_ = normalize((self.target.pos[0]-self.pos[0], self.target.pos[1]-self.pos[1]))
                if self.aistyle == 'shotgun' or self.aistyle == 'shotgun+':
                    for i in range(self.ai['bullets']):
                        vel__ = rotateVector(vel_, randint(-self.ai['spread_angle'], self.ai['spread_angle']))
                        projectiles.append(Projectile((self.pos[0]+int(self.width/2), self.pos[1]+int(self.width/2)), vel__, self.ai['shoot_speed'], team='enemy'))
                else:
                    projectiles.append(Projectile((self.pos[0]+int(self.width/2), self.pos[1]+int(self.width/2)), vel_, self.ai['shoot_speed'], team='enemy', bounces=(3 if self.aistyle =='bouncer' else 0)))

            # -- movement -- #
            # BASIC
            if self.aistyle == 'basic' or self.aistyle=='rifle' or self.aistyle=='bouncer':
                if dist(self.pos, (self.target.pos[0],self.target.pos[1]))>self.ai['idle_distance']:
                    vel_ = normalize((self.target.pos[0]-self.pos[0], self.target.pos[1]-self.pos[1]))
                    self.pos = ( self.pos[0]+vel_[0]*self.speed , self.pos[1]+vel_[1]*self.speed )
                elif dist(self.pos, (self.target.pos[0],self.target.pos[1]))<self.ai['retreat_distance']:
                    vel_ = normalize((self.target.pos[0]-self.pos[0], self.target.pos[1]-self.pos[1]))
                    self.pos = ( self.pos[0]+vel_[0]*-self.speed , self.pos[1]+vel_[1]*-self.speed )

            # SHOTGUN
            elif self.aistyle == 'shotgun':
                self.ai['circle_vel'] = rotateVector((-self.ai['circle_radius']-2, 0), self.ai['circle_angle'])
                self.ai['circle_angle'] += 1
                circle_point = (self.target.pos[0]+self.ai['circle_vel'][0], self.target.pos[1]+self.ai['circle_vel'][1])
                vel_ = normalize((circle_point[0]-self.pos[0], circle_point[1]-self.pos[1]))
                self.pos = ( self.pos[0]+vel_[0]*self.speed , self.pos[1]+vel_[1]*self.speed )

            # BOUNCER
            '''
            elif self.aistyle == 'bouncer':
                self.ai['circle_vel'] = rotateVector((-self.ai['circle_radius']-2, 0), self.ai['circle_angle'])
                self.ai['circle_angle'] += 1
                circle_point = (self.target.pos[0]+self.ai['circle_vel'][0], self.target.pos[1]+self.ai['circle_vel'][1])
                vel_ = normalize((circle_point[0]-self.pos[0], circle_point[1]-self.pos[1]))
                self.pos = ( self.pos[0]+vel_[0]*self.speed , self.pos[1]+vel_[1]*self.speed )
            '''

            # keep minimum distance
            for e_ in enemies:
                if e_ != self:
                    if dist(self.pos, e_.pos)<30+(e_.width-20):
                        vel_ = normalize((e_.pos[0]-self.pos[0], e_.pos[1]-self.pos[1]))
                        self.pos = ( self.pos[0]+vel_[0]*-self.speed , self.pos[1]+vel_[1]*-self.speed )

            # ----- LIFE ----- #
            # life
            if self.life <=0:
                enemies.remove(self)

            if self.hitFrame<5:
                self.color_ = (255,255,255)
                self.hitFrame -=1
                if self.hitFrame <= 0:
                    self.hitFrame = 5
            else:
                self.color_ = self.color
        else:
            for j in range(2 if current_fps>=58 else 1 if current_fps>=50 else 0):
                vec = rotateVector([1,1], randint(-180,180))
                coef = randint(50,100)
                r = self.color[0]*(coef/100)
                g = self.color[1]*(coef/100)
                b = self.color[2]*(coef/100)
                particles.append([(self.pos[0]+self.width/2+randint(-3,3), self.pos[1]+self.width/2+randint(-3,3)), vec, (r,g,b), 8])
            self.spawntime -= 1

    def hit(self):
        self.hitFrame -= 1
        self.life -= 1

    def displayData(self, screen):
        if self.aistyle == 'basic' or self.aistyle == 'rifle' or self.aistyle == 'bouncer':
            pygame.draw.circle(screen,(0,25,0),(int(self.pos[0]+self.width/2),int(self.pos[1]+self.width/2)),self.ai['retreat_distance'], 2)
            pygame.draw.circle(screen,(25,25,0),(int(self.pos[0]+self.width/2),int(self.pos[1]+self.width/2)),self.ai['idle_distance'], 2)

    def draw(self, screen):
        pygame.draw.rect(screen, self.color_, pygame.Rect(self.pos[0], self.pos[1], self.width, self.width))