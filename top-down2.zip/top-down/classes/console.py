class Console:
    def __init__(self):
        self.writing = False
        self.text_entry = ''
        self.univ_line = 1
        self.console = []