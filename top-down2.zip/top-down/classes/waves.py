wave = 0
waveTime = 60
waves = [
    {'basic':0,'rifle':0,'shotgun':0},
    {'basic':2,'rifle':0,'shotgun':0},
    {'basic':3,'rifle':1,'shotgun':0},
    {'basic':1,'rifle':3,'shotgun':0},
    {'basic':0,'rifle':3,'shotgun':2},
    {'basic':0,'rifle':0,'shotgun':4},
]