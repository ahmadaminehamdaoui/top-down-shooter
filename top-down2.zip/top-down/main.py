# TO DO
# particles reduction system
# + 1(2) more aistyles
# ui
# weapons system

# MODULES
import pygame, ctypes
from math import *
from random import randint, uniform
# .PY
from funcs import *
from classes.player import Player
from classes.enemy import Enemy
from classes.projectile import Projectile
from classes.label import Label
from classes.cursor import Cursor
from classes.screen import Screen
from classes.console import Console
from classes.waves import waves, wave, waveTime

a=0
use_qwerty = True
isDev = False
fps_log =  []
fps_logger = 10
fps_max = 60
rules = []

# pygame setup
pygame.init()
pygame.display.init()
pygame.display.set_caption('main')
screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
clock = pygame.time.Clock()
font = pygame.font.Font('fonts/OpenSans-Regular.ttf', 13)
pygame.mouse.set_visible(0)

# classes init
cursor = Cursor()
scr = Screen()
console = Console()
player = Player(position=scr.cen, speed=5)

# lists init
enemies = []
projectiles = []
particles = []

label_fps = Label((0,0), size=13, text='', centered=False)
label_entities = Label((0,21), size=13, text='', centered=False)
labels = [label_fps, label_entities]

# funcs
def cprint(text):
    console.console.insert(0, '['+str(console.univ_line)+']  '+str(text))
    console.univ_line += 1

# MAIN LOGIC
while True:
    # --- init --- #
    screen.fill((0,0,0))
    cursor.pos = pygame.mouse.get_pos()
    current_fps = round(clock.get_fps(),1)

    # fps tracker
    label_fps.text = ''
    label_entities.text = ''
    if isDev:
        label_fps.text = 'FPS: '+str(current_fps)
        label_entities.text = 'ENTITIES: '+str(len(projectiles))+str(len(particles))

        # graph
        fps_logger -= 1
        if fps_logger <= 0:
            fps_logger = 5
            fps_log.insert(0, current_fps)
        for i in range(0, len(fps_log)-250):
            fps_log.pop()
    else:
        fps_log = []

    # ----- rules -----#
    for rule in rules:
        exec(rule)

    # ----- waves -----#
    if enemies == []:
        waveTime -= 1
        if waveTime <= 0:
            waveTime = 60
            wave += 1
            if wave < len(waves):
                for key, value in waves[wave].items():
                    for i in range(value):
                        e_ = Enemy(target=player, aistyle=key, pos=(randint(0,scr.w),randint(0,scr.h)))
                        enemies.append(e_)

    # ----- updates ----- #
    player.update(scr)
    cursor.update(player, projectiles, enemies, particles)
    for e in enemies:
        e.update(player, projectiles, enemies, particles, current_fps)
    for p in projectiles: p.update(player, projectiles, enemies, particles, current_fps, scr)

    # ------- event handler ------- #
    for event in pygame.event.get():
        # keydow events
        if event.type == pygame.KEYDOWN:
            # ENTRY
            if console.writing:
                if event.key == pygame.K_RETURN:
                    if console.text_entry !=  '':
                        cmd = console.text_entry.split()
                        # cursor_attribute COMMAND
                        if cmd[0]=='power' or cmd[0]=='op':
                            cursor.clickDelayMax = 1
                        # spawn COMMAND
                        elif len(cmd)==3 and (cmd[0]=='spawn' or cmd[0]=='s') and cmd[1].isdigit():
                            try:
                                for i in range(int(cmd[1])):
                                    enemies.append(Enemy(target=player, aistyle=cmd[2], pos=(randint(0,scr.w),randint(0,scr.h))))
                                cprint('Spawned '+cmd[1]+' '+cmd[2])
                            except:
                                cprint('"'+cmd[2]+'" is not a valid aitype')
                        # exec COMMAND
                        elif cmd[0]=='exec':
                                argument = ''
                                for i in range(1, len(cmd)):
                                    argument+=cmd[i]+' '
                                try:
                                    exec(argument)
                                    cprint('"'+argument+'" has been executed')
                                except:
                                    cprint('"'+argument+'" cannot be executed')
                        # rule COMMAND
                        elif cmd[0]=='rule':
                                argument = ''
                                for i in range(1, len(cmd)):
                                    argument+=cmd[i]+' '
                                if argument=='clear ':
                                    rules = []
                                    cprint('The rules have been cleared')
                                else:
                                    try:
                                        exec(argument)
                                        cprint('The rule "'+argument+'" has been created')
                                        rules.append(argument)
                                    except:
                                        cprint('The rule"'+argument+'" cannot be created')
                         # clear COMMAND
                        elif cmd[0]=='clear':
                            while enemies != []:
                                for e in enemies:
                                    enemies.remove(e)
                            while projectiles != []:
                                for p in projectiles:
                                    projectiles.remove(p)
                        else:
                            cprint('"'+console.text_entry+'" is not a valid command')
                    console.text_entry = ''
                    console.writing = False
                elif event.key == pygame.K_BACKSPACE:
                    console.text_entry = console.text_entry[:-1]
                else:
                    console.text_entry += event.unicode
            else:
                if event.key == pygame.K_RETURN:
                    console.writing = not(console.writing)
            #

            if event.key == pygame.K_ESCAPE:
                shutdown()
            elif event.key == pygame.K_F3:
                isDev = not isDev
                if isDev:
                    cprint('Developer mode is enabled')
                else:
                    cprint('Developer mode is disabled')

            # player movement
            elif event.key == pygame.K_d and not console.writing:
                player.vel['right'] = 1
            elif event.key == pygame.K_z and not console.writing:
                if not use_qwerty:
                    player.vel['up'] = 1
            elif event.key == pygame.K_q and not console.writing:
                if not use_qwerty:
                    player.vel['left'] = 1
            elif event.key == pygame.K_s and not console.writing:
                player.vel['down'] = 1
                #
            elif event.key == pygame.K_a and not console.writing:
                if use_qwerty:
                    player.vel['left'] = 1
            elif event.key == pygame.K_w and not console.writing:
                    player.vel['up'] = 1
            elif event.key == pygame.K_SPACE:
                player.isDashing = True

        elif event.type == pygame.KEYUP:
            # player movement
            if event.key == pygame.K_d:
                player.vel['right'] = 0
            elif event.key == pygame.K_z:
                if not use_qwerty:
                    player.vel['up'] = 0
            elif event.key == pygame.K_q:
                if not use_qwerty:
                    player.vel['left'] = 0
            elif event.key == pygame.K_s:
                player.vel['down'] = 0
                #
            elif event.key == pygame.K_a:
                if use_qwerty:
                    player.vel['left'] = 0
            elif event.key == pygame.K_w:
                    player.vel['up'] = 0

        # Mouse
        elif event.type == pygame.MOUSEBUTTONDOWN:
            cursor.click = True
        elif event.type == pygame.MOUSEBUTTONUP:
            cursor.click = False

        # other events
        elif event.type == pygame.QUIT:
            shutdown()

    # ----- drawing ----- #
    # dev
    if isDev:
        for e in enemies:
            e.displayData(screen)
        for j in range(len(fps_log)):
            if j > 0:
                pygame.draw.line(screen, (0,255,0), (100+(j-1)*3, int(25+(fps_max*2-fps_log[j-1]*2))), (100+j*3, int(25+(fps_max*2-fps_log[j]*2))))

    # console
    for i in range(0, len(console.console)-20):
        console.console.pop()
    for i in range(len(console.console)):
        text = font.render(console.console[i], 1, (255,255,255))
        screen.blit(text, (0, scr.h-35-15*i))
    if console.writing:
        screen.blit(font.render('>> '+console.text_entry, 1, (255,255,255)), (0, scr.h-20))

    # labels
    for l in labels:
        l.draw(screen, l.text)

    # projs
    for proj in projectiles:
        proj.draw(screen)

    # particle
    for p in particles:
        p[0] = (p[0][0]+p[1][0], p[0][1]+p[1][1])
        p[3] -= 0.2
        pygame.draw.rect(screen, p[2], pygame.Rect(p[0][0], p[0][1], p[3], p[3]))
        # pygame.draw.circle(screen, p[2], p[0], p[3], 0)
        if p[3] <= 0:
            particles.remove(p)

    # enemies
    for e in enemies:
        if e.spawntime <= 0:
            e.draw(screen)

    # player
    player.draw(screen)


    # cursor
    screen.blit(cursor.sprite, (cursor.pos[0]+12, cursor.pos[1]+10))

    # --- update ---#
    pygame.display.update()
    clock.tick(fps_max)
