import pygame, sys, ctypes
from math import *
from classes import *
from random import  randint

a=0
use_qwerty = True
isDev = False
fps_log =  []
fps_logger = 10
fps_max = 60

# CONSOLE
univ_line = 1
console = []
def cprint(text):
    global univ_line
    console.insert(0, '['+str(univ_line)+']  '+str(text))
    univ_line += 1

# SETUP
pygame.init()
pygame.display.init()
pygame.display.set_caption('main')
screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
clock = pygame.time.Clock()
font = pygame.font.Font('OpenSans-Regular.ttf', 13)

user32 = ctypes.windll.user32
class Screen:
    def __init__(self):
        self.w, self.h = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)
        self.w_2 = int(self.w/2)
        self.h_2 = int(self.h/2)
        self.cen = (self.w_2, self.h_2)
scr = Screen()

# FUNCTIONS
def shutdown():
    pygame.quit()
    sys.exit()

def normalize(vec):
    try:
        length = sqrt(vec[0]**2 + vec[1]**2)
        vec = (vec[0]/length, vec[1]/length)
        return vec
    except: return (0,0)

def dist(p1,p2):
    return sqrt((p2[0]-p1[0])**2+(p2[1]-p1[1])**2)

# GAME FUNCTIONS
def isColliding(rect1, rect2, width1, width2):
    width1 -= 1
    width2 -= 1
    if rect1[0] < rect2[0]+width2 and rect1[0]+width1 > rect2[0] and rect1[1] < rect2[1] + width2 and width1 + rect1[1] > rect2[1]:
        return True
    return False

def isPointColliding(point, rect, width):
    width -= 1
    # 3EME ET + A FINIR
    if point[0]<rect[0]+width and point[0]>rect[0] and point[1]<rect[1]+width and point[1]>rect[1]:
        return True
    return False

# CLASSES INIT
cursor = Cursor()
player = Player(position=scr.cen, speed=5)
projectiles = []

labels = []
label_fps = Label(Vec2(0,0), size=13, text='', centered=False)
labels.append(label_fps)
label_entities = Label(Vec2(0,21), size=13, text='', centered=False)
labels.append(label_entities)

enemies = []
enemies.append(Enemy(player, aistyle='shotgun', pos=(randint(0,scr.w),randint(0,scr.h))))
'''
for i in range(10):
    enemies.append(Enemy(player, aistyle='stealth+', pos=(randint(0,scr.w),randint(0,scr.h))))
'''


# MAIN LOGIC
while True:
    # --- init --- #
    screen.fill((0,0,0))
    cursor.pos = pygame.mouse.get_pos()
    current_fps = round(clock.get_fps(),1)

    # fps tracker
    label_fps.text = ''
    label_entities.text = ''
    if isDev:
        label_fps.text = 'FPS: '+str(current_fps)
        label_entities.text = 'ENTITIES: '+str(len(projectiles))

        # graph
        fps_logger -= 1
        if fps_logger <= 0:
            fps_logger = 5
            fps_log.insert(0, current_fps)
        for i in range(0, len(fps_log)-250):
            fps_log.pop()
    else:
        fps_log = []

    # --- player --- #
    for i in range(player.speed):
        player.pos = ( player.pos[0]+(player.vel['right']-player.vel['left']) , player.pos[1]+(player.vel['down']-player.vel['up']) )
    if player.isDashing:
        player.color = (0,255,255)
        player.speed = player.baseSpeed*4
        player.dashTime -= 1
        if player.dashTime <= 0:
            player.dashTime = player.dashBaseTime
            player.isDashing = False
    else:
        player.color = (255,255,255)
        player.speed = player.baseSpeed

    # --- enemies --- #
    for e in enemies:
        e.update()

        # life
        if e.life <=0:
            enemies.remove(e)
        # charger
        if e.ai['charger']<=0:
            e.ai['reload-delay'] -= 1
            if e.ai['reload-delay']<=0:
                e.ai['reload-delay'] = e.ai['reload-delayMax']
                e.ai['charger'] = e.ai['chargerMax']

        # shooting
        elif e.ai['shoot_delay']<=0:
            e.ai['charger'] -= 1
            e.ai['shoot_delay'] = e.ai['shoot_delayMax']
            vel_ = normalize((e.target.pos[0]-e.pos[0], e.target.pos[1]-e.pos[1]))
            projectiles.append(Projectile((e.pos[0]+int(e.width/2), e.pos[1]+int(e.width/2)), vel_, e.ai['shoot_speed'], team='enemy'))
            if e.aistyle == 'shotgun':
                angle = radians(15)
                cprint(str(cos(angle))+' '+str(sin(angle)))
                vel__ = (vel_[0] * cos(angle) - vel_[1] * sin(angle), vel_[0] * sin(angle) + vel_[1] * cos(angle))
                projectiles.append(Projectile((e.pos[0]+int(e.width/2), e.pos[1]+int(e.width/2)), vel__, e.ai['shoot_speed'], team='enemy'))
                vel__ = (vel_[0] * cos(-angle) - vel_[1] * sin(-angle), vel_[0] * sin(-angle) + vel_[1] * cos(-angle))
                projectiles.append(Projectile((e.pos[0]+int(e.width/2), e.pos[1]+int(e.width/2)), vel__, e.ai['shoot_speed'], team='enemy'))
        for e_ in enemies:
            if e_ != e:
                if dist(e.pos, e_.pos)<30:
                    vel_ = normalize((e_.pos[0]-e.pos[0], e_.pos[1]-e.pos[1]))
                    e.pos = ( e.pos[0]+vel_[0]*-e.speed , e.pos[1]+vel_[1]*-e.speed )

    # --- projectiles --- #
    for proj in projectiles:
        for i in range(proj.speed):
            if proj.team == 'player':
                for e in enemies:
                    if isColliding(proj.pos, e.pos, proj.width, e.width):
                        if proj in projectiles:
                            e.hit()
                            projectiles.remove(proj)
                            break
                proj.pos = ( proj.pos[0]+proj.vel[0] , proj.pos[1]+proj.vel[1] )
                proj.oldPos.append(proj.pos)
            else:
                if isColliding(proj.pos, player.pos, proj.width, player.width):
                    projectiles.remove(proj)
                    break
                else:
                    proj.pos = ( proj.pos[0]+proj.vel[0] , proj.pos[1]+proj.vel[1] )
                    proj.oldPos.append(proj.pos)

    # --- mouse events --- #
    if cursor.click and cursor.clickDelay <= 0:
        cursor.clickDelay = 1
        for i in range(1):
            vel = normalize((cursor.pos[0]-player.pos[0], cursor.pos[1]-player.pos[1]))
            projectiles.append(Projectile((player.pos[0]+int(player.width/2), player.pos[1]+int(player.width/2)), vel, 25, team='player'))
    cursor.clickDelay -= 1

    # --- collisions --- #
    for proj in projectiles:
        if (proj.pos[0]<0 or proj.pos[0]>scr.w or proj.pos[1]<0 or proj.pos[1]>scr.h or proj.lifeTime <= 0):
            projectiles.remove(proj)
        proj.lifeTime -= 1

    # ------- event handler ------- #
    for event in pygame.event.get():
        # keydow events
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                shutdown()
            elif event.key == pygame.K_F3:
                isDev = not isDev
                if isDev:
                    cprint('Mode développeur activé')
                else:
                    cprint('Mode développeur désactivé')
            # player movement
            elif event.key == pygame.K_d:
                player.vel['right'] = 1
            elif event.key == pygame.K_z:
                if not use_qwerty:
                    player.vel['up'] = 1
            elif event.key == pygame.K_q:
                if not use_qwerty:
                    player.vel['left'] = 1
            elif event.key == pygame.K_s:
                player.vel['down'] = 1
                #
            elif event.key == pygame.K_a:
                if use_qwerty:
                    player.vel['left'] = 1
            elif event.key == pygame.K_w:
                    player.vel['up'] = 1
            elif event.key == pygame.K_SPACE:
                player.isDashing = True

        elif event.type == pygame.KEYUP:
            # player movement
            if event.key == pygame.K_d:
                player.vel['right'] = 0
            elif event.key == pygame.K_z:
                if not use_qwerty:
                    player.vel['up'] = 0
            elif event.key == pygame.K_q:
                if not use_qwerty:
                    player.vel['left'] = 0
            elif event.key == pygame.K_s:
                player.vel['down'] = 0
                #
            elif event.key == pygame.K_a:
                if use_qwerty:
                    player.vel['left'] = 0
            elif event.key == pygame.K_w:
                    player.vel['up'] = 0

        # Mouse
        elif event.type == pygame.MOUSEBUTTONDOWN:
            cursor.click = True
        elif event.type == pygame.MOUSEBUTTONUP:
            cursor.click = False

        # other events
        elif event.type == pygame.QUIT:
            shutdown()

    # --- drawing --- #
    if isDev:
        pygame.draw.circle(screen,(25,25,0),(player.pos[0]+int(player.width/2),player.pos[1]+int(player.width/2)),225)
        pygame.draw.circle(screen,(0,25,0),(player.pos[0]+int(player.width/2),player.pos[1]+int(player.width/2)),145)
        for j in range(len(fps_log)):
            if j > 0:
                pygame.draw.line(screen, (0,255,0), (100+(j-1)*3, int(25+(fps_max*2-fps_log[j-1]*2))), (100+j*3, int(25+(fps_max*2-fps_log[j]*2))))
        '''
        for proj in projectiles:
            for p in proj.oldPos:
                pygame.draw.rect(screen, (0,0,100), pygame.Rect(p[0], p[1], proj.width, proj.width))
        '''

    if cursor.shown:
        pygame.mouse.set_visible(1)
    else:
        pygame.mouse.set_visible(0)

    # cursor
    pygame.draw.rect(screen, cursor.color, pygame.Rect(cursor.pos[0], cursor.pos[1], cursor.width, cursor.width))

    # player
    pygame.draw.rect(screen, player.color, pygame.Rect(player.pos[0], player.pos[1], player.width, player.width))


    # enemies
    for e in enemies:
        pygame.draw.rect(screen, e.color_, pygame.Rect(e.pos[0], e.pos[1], e.width, e.width))

    # projs
    for proj in projectiles:
        pygame.draw.rect(screen, proj.color, pygame.Rect(proj.pos[0], proj.pos[1], proj.width, proj.width))

    # console
    for i in range(0, len(console)-20):
        console.pop()
    if isDev:
        for i in range(len(console)):
            text = font.render(console[i], 1, (255,255,255))
            screen.blit(text, (0, scr.h-20-15*i))

    # labels
    for l in labels:
        l.draw(screen, l.text)

    # --- update ---#
    pygame.display.update()
    clock.tick(fps_max)
