import pygame
from math import sqrt
from random import randint

def normalize(vec):
    try:
        length = sqrt(vec[0]**2 + vec[1]**2)
        vec = (vec[0]/length, vec[1]/length)
        return vec
    except: return (0,0)
def s(time):
    return time*60

def dist(p1,p2):
    return sqrt((p2[0]-p1[0])**2+(p2[1]-p1[1])**2)

# --- GAME --- #
class Vec2:
    def __init__(self, x=None, y=None, tuple=None):
        if tuple == None:
            self.x = x
            self.y = y
        else:
            self.x = tuple[0]
            self.y = tuple[1]

class Cursor:
    def __init__(self):
        # specifics
        self.pos = [-100,-100]

        # shooting
        self.click = False
        self.clickDelay = 1
        self.shown = False
        self.data = None

        # sprite
        self.width = 6
        self.color = (100,100,100)

class Player:
    def __init__(self,
                 position=(0,0),
                 velocity={'right':0, 'up':0, 'left':0, 'down':0},
                 speed=2
                ):
        # position
        self.pos = position
        self.vel = velocity
        self.speed = speed
        self.baseSpeed = speed

        # states
        self.isDashing = False
        self.dashTime = 10
        self.dashBaseTime = 10

        # sprite
        self.width = 20
        self.color = (255,255,255)

class Projectile:
    def __init__(self, pos, vel, speed, team='enemy'):
        # position
        self.pos = pos
        self.vel = vel
        self.speed = speed
        self.lifeTime = 120

        # sprite
        self.width = 4
        self.color = (255,255,255)

        # others
        self.team = team
        self.oldPos = []

class Enemy:
    def __init__(self,
                 target,
                 aistyle='basic',
                 pos=(1000,250),
                ):
            # position
            self.pos = pos
            self.vel = (0,0)
            self.target = target

            self.hitFrame = 5
            # AI
            self.aistyle = aistyle
            self.ai = {}
            if self.aistyle == 'basic':
                self.ai = {'shoot_speed':7,
                           'shoot_delayMax':45,
                           'shoot_delay':45,
                           'reload-delayMax':0,
                           'reload_delay':0,
                           'charger':1000,
                           'chargerMax':1000,

                           'retreat-distance':145,
                           'idle-distance':225
                           }
                self.color = (255,0,0)
                self.speed = 2
                self.life = 4

            elif self.aistyle == 'basic+':
                self.ai = {'shoot_speed':10,
                           'shoot_delayMax':40,
                           'shoot_delay':40,
                           'reload-delayMax':0,
                           'reload_delay':0,
                           'charger':1000,
                           'chargerMax':1000,

                           'retreat-distance':145,
                           'idle-distance':225
                           }
                self.color = (150,0,0)
                self.speed = 3.25
                self.life = 5

            elif self.aistyle == 'stealth':
                self.ai = {'shoot_speed':8,
                           'shoot_delayMax':4,
                           'shoot_delay':4,
                           'reload-delayMax':80,
                           'reload-delay':80,
                           'charger':4,
                           'chargerMax':4,

                           'stealth-distance':300
                          }
                self.color = (255,196,0)
                self.speed = 2.5
                self.life = 3

            elif self.aistyle == 'stealth+':
                self.ai = {'shoot_speed':10,
                           'shoot_delayMax':4,
                           'shoot_delay':4,
                           'reload-delayMax':70,
                           'reload-delay':70,
                           'charger':5,
                           'chargerMax':5,

                           'stealth-distance':300
                          }
                self.color = (150,91,0)
                self.speed = 3.75
                self.life = 4

            elif self.aistyle == 'shotgun':
                self.ai = {'shoot_speed':10,
                           'shoot_delayMax':100,
                           'shoot_delay':100,
                           'reload-delayMax':0,
                           'reload-delay':0,
                           'charger':1000,
                           'chargerMax':1000,
                          }
                self.color = (0,255,0)
                self.speed = 2
                self.life = 10

            # sprite
            self.width = 20

    def update(self):
        # ----- AI
        self.ai['shoot_delay'] -= 1
        if self.aistyle == 'basic' or self.aistyle == 'basic+':
            if dist(self.pos, self.target.pos)>self.ai['idle-distance']:
                vel_ = normalize((self.target.pos[0]-self.pos[0], self.target.pos[1]-self.pos[1]))
                self.pos = ( self.pos[0]+vel_[0]*self.speed , self.pos[1]+vel_[1]*self.speed )
            elif dist(self.pos, self.target.pos)<self.ai['retreat-distance']:
                vel_ = normalize((self.target.pos[0]-self.pos[0], self.target.pos[1]-self.pos[1]))
                self.pos = ( self.pos[0]+vel_[0]*-self.speed , self.pos[1]+vel_[1]*-self.speed )
        elif self.aistyle == 'stealth' or self.aistyle =='stealth+':
            offset = (self.target.vel['right']-self.target.vel['left'],self.target.vel['down']-self.target.vel['up'])
            if offset != (0,0):
                vel_ = normalize((self.target.pos[0]-offset[0]*self.ai['stealth-distance']-self.pos[0], self.target.pos[1]-offset[1]*self.ai['stealth-distance']-self.pos[1]))
                self.pos = ( self.pos[0]+vel_[0]*self.speed , self.pos[1]+vel_[1]*self.speed )
        elif self.aistyle == 'shotgun':
            pass
        # ----- ANIMATION
        if self.hitFrame<5:
            self.color_ = (255,255,255)
            self.hitFrame -=1
            if self.hitFrame <= 0:
                self.hitFrame = 5
        else:
            self.color_ = self.color

    def hit(self):
        self.hitFrame -= 1
        self.life -= 1

# --- UI --- #
class Label:
    def __init__(self, position, size=15, color=(255,255,255), text='', centered=True):
        self.position = position
        self.size = size
        self.color = color
        self.text = text
        self.centered = centered

    def draw(self, surface, text=''):
        if text != '':
            font = pygame.font.Font('OpenSans-Regular.ttf', self.size)
            text = font.render(text, 1, self.color)
            if self.centered:
                surface.blit(text, (self.position.x-text.get_width()/2, self.position.y-text.get_height()/2))
            else:
                surface.blit(text, (self.position.x, self.position.y))